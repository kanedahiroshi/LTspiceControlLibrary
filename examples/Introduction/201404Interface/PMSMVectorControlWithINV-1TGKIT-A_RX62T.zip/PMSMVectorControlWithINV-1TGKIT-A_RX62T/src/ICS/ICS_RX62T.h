
#define   ICS_SCI0_PB2_PB1    (0x00)
#define   ICS_SCI1_PD3_PD5    (0x10)
#define   ICS_SCI2_PB5_PB6    (0x20)
#define   ICS_SCI2_P81_P80    (0x21)

void ics_init(void * addr, char port, char level);
void ics_watchpoint(void);

void ics_int_sci_rxi(void);
void ics_int_sci_eri(void);


