/***********************************************************************/
/*                                                                     */
/*  FILE        :lowsrc.h                                              */
/*  DATE        :Tue, Oct 31, 2006                                     */
/*  DESCRIPTION :Header file of I/O Stream file                        */
/*  CPU TYPE    :                                                      */
/*                                                                     */
/*  NOTE:THIS IS A TYPICAL EXAMPLE.                                    */
/*                                                                     */
/***********************************************************************/
/*Number of I/O Stream*/
#define IOSTREAM 3
