#include "HallSensor.h"
#include <stdint.h>
#include <iodefine.h>

void HallSensor_initialize(void) {
   _HallSensor_U_PORT.ICR.BIT._HallSensor_U_BIT = 1;
   _HallSensor_U_PORT.DDR.BIT._HallSensor_U_BIT = 0;
   _HallSensor_V_PORT.ICR.BIT._HallSensor_V_BIT = 1;
   _HallSensor_V_PORT.DDR.BIT._HallSensor_V_BIT = 0;
   _HallSensor_W_PORT.ICR.BIT._HallSensor_W_BIT = 1;
   _HallSensor_W_PORT.DDR.BIT._HallSensor_W_BIT = 0;
}

#if _HallSensor_HAS_INTERRUPT_U_FUNCTION
void HallSensor_initializeInterruptU(uint8_t priority, uint8_t mode) {
    HallSensor_disableInterruptU();
    HallSensor_clearInterruptURequest();
    _HallSensor_U_IPR = priority;
    _HallSensor_selectPinUAsIRQ();
    ICU.IRQCR[_HallSensor_U_IRQ].BIT.IRQMD = mode;
    HallSensor_clearInterruptURequest();
}
#endif /* _HallSensor_HAS_INTERRUPT_U_FUNCTION */

#if _HallSensor_HAS_INTERRUPT_V_FUNCTION
void HallSensor_initializeInterruptV(uint8_t priority, uint8_t mode) {
    HallSensor_disableInterruptV();
    HallSensor_clearInterruptVRequest();
    _HallSensor_V_IPR = priority;
    _HallSensor_selectPinVAsIRQ();
    ICU.IRQCR[_HallSensor_V_IRQ].BIT.IRQMD = mode;
    HallSensor_clearInterruptVRequest();
}
#endif /* _HallSensor_HAS_INTERRUPT_V_FUNCTION */

#if _HallSensor_HAS_INTERRUPT_W_FUNCTION
void HallSensor_initializeInterruptW(uint8_t priority, uint8_t mode) {
    HallSensor_disableInterruptW();
    HallSensor_clearInterruptWRequest();
    _HallSensor_W_IPR = priority;
    _HallSensor_selectPinWAsIRQ();
    ICU.IRQCR[_HallSensor_W_IRQ].BIT.IRQMD = mode;
    HallSensor_clearInterruptWRequest();
}
#endif /* _HallSensor_HAS_INTERRUPT_W_FUNCTION */
