#ifndef _HallSensor
#define _HallSensor

#include <stdint.h>
#include <iodefine.h>

#define HallSensor_NONE   (0x00)
#define HallSensor_U   (0x01)
#define HallSensor_V   (0x02)
#define HallSensor_W   (0x04)

#define _HallSensor_U_PORT   PORT1
#define _HallSensor_U_BIT   B0
#define _HallSensor_U_ACTIVE_LOGIC   0
#define _HallSensor_V_PORT   PORT1
#define _HallSensor_V_BIT   B1
#define _HallSensor_V_ACTIVE_LOGIC   0
#define _HallSensor_W_PORT   PORTB
#define _HallSensor_W_BIT   B4
#define _HallSensor_W_ACTIVE_LOGIC   0

void HallSensor_initialize(void);
#define HallSensor_isUOn()   (_HallSensor_U_PORT.PORT.BIT._HallSensor_U_BIT == _HallSensor_U_ACTIVE_LOGIC)
#define HallSensor_isVOn()   (_HallSensor_V_PORT.PORT.BIT._HallSensor_V_BIT == _HallSensor_V_ACTIVE_LOGIC)
#define HallSensor_isWOn()   (_HallSensor_W_PORT.PORT.BIT._HallSensor_W_BIT == _HallSensor_W_ACTIVE_LOGIC)
#define HallSensor_getUVW()   ((HallSensor_isUOn() << 0) | (HallSensor_isVOn() << 1) | (HallSensor_isWOn() << 2))


#define _HallSensor_HAS_INTERRUPT_U_FUNCTION   1
#if _HallSensor_HAS_INTERRUPT_U_FUNCTION
#include "IRQ.h"
#define _HallSensor_U_IRQ   0
#define _HallSensor_U_IR   IR(ICU, IRQ0)
#define _HallSensor_U_IPR   IPR(ICU, IRQ0)
#define _HallSensor_U_IEN   IEN(ICU, IRQ0)
#define _HallSensor_selectPinUAsIRQ()   (IOPORT.PF8IRQ.BIT.ITS0 = 0)

void HallSensor_initializeInterruptU(uint8_t priority, uint8_t mode);
#define HallSensor_enableInterruptU()   (_HallSensor_U_IEN = 1)
#define HallSensor_disableInterruptU()   (_HallSensor_U_IEN = 0)
#define HallSensor_isInterruptUEnabled()   (_HallSensor_U_IEN != 0)
#define HallSensor_clearInterruptURequest()   (_HallSensor_U_IR = 0)
#define HallSensor_isInterruptURequested()   (_HallSensor_U_IR != 0)
#endif /* _HallSensor_HAS_INTERRUPT_U_FUNCTION */


#define _HallSensor_HAS_INTERRUPT_V_FUNCTION   1
#if _HallSensor_HAS_INTERRUPT_V_FUNCTION
#include "IRQ.h"
#define _HallSensor_V_IRQ   1
#define _HallSensor_V_IR   IR(ICU, IRQ1)
#define _HallSensor_V_IPR   IPR(ICU, IRQ1)
#define _HallSensor_V_IEN   IEN(ICU, IRQ1)
#define _HallSensor_selectPinVAsIRQ()   (IOPORT.PF8IRQ.BIT.ITS1 = 0)

void HallSensor_initializeInterruptV(uint8_t priority, uint8_t mode);
#define HallSensor_enableInterruptV()   (_HallSensor_V_IEN = 1)
#define HallSensor_disableInterruptV()   (_HallSensor_V_IEN = 0)
#define HallSensor_isInterruptVEnabled()   (_HallSensor_V_IEN != 0)
#define HallSensor_clearInterruptVRequest()   (_HallSensor_V_IR = 0)
#define HallSensor_isInterruptVRequested()   (_HallSensor_V_IR != 0)
#endif /* _HallSensor_HAS_INTERRUPT_V_FUNCTION */


#define _HallSensor_HAS_INTERRUPT_W_FUNCTION   1
#if _HallSensor_HAS_INTERRUPT_W_FUNCTION
#include "IRQ.h"
#define _HallSensor_W_IRQ   3
#define _HallSensor_W_IR   IR(ICU, IRQ3)
#define _HallSensor_W_IPR   IPR(ICU, IRQ3)
#define _HallSensor_W_IEN   IEN(ICU, IRQ3)
#define _HallSensor_selectPinWAsIRQ()

void HallSensor_initializeInterruptW(uint8_t priority, uint8_t mode);
#define HallSensor_enableInterruptW()   (_HallSensor_W_IEN = 1)
#define HallSensor_disableInterruptW()   (_HallSensor_W_IEN = 0)
#define HallSensor_isInterruptWEnabled()   (_HallSensor_W_IEN != 0)
#define HallSensor_clearInterruptWRequest()   (_HallSensor_W_IR = 0)
#define HallSensor_isInterruptWRequested()   (_HallSensor_W_IR != 0)
#endif /* _HallSensor_HAS_INTERRUPT_W_FUNCTION */

#endif /* _HallSensor */
