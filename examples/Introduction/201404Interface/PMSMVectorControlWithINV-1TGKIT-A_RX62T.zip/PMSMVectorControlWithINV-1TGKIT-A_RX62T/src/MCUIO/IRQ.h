#ifndef _IRQ
#define _IRQ

#define IRQ_MODE_LOW_LEVEL   0
#define IRQ_MODE_FALLING_EDGE   1
#define IRQ_MODE_RISING_EDGE   2
#define IRQ_MODE_BOTH_EDGES   3

#endif /* _IRQ */
