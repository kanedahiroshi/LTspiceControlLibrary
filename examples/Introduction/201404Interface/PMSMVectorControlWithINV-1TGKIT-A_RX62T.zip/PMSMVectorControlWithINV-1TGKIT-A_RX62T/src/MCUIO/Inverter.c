#include "Inverter.h"
#include <iodefine.h>
#include <stdint.h>
#include "MCUIO.h"

#define CARRIER_FREQUENCY_HZ   (Inverter_CARRIER_FREQUENCY_HZ)
#define DEADTIME_S   (Inverter_DEADTIME_S)

#define HALF_PERIOD   ((uint16_t)(Inverter_TIMER_CLOCK_HZ / (CARRIER_FREQUENCY_HZ * 2)))
#define DEADTIME   ((uint16_t)(Inverter_TIMER_CLOCK_HZ * DEADTIME_S))
#define HALF_PERIOD_AND_DEADTIME   (HALF_PERIOD + DEADTIME)

static void initializeS12AD0(void);
static void initializeS12AD1(void);
static void initializeADCMP(void);
static void initializePOE(void);
static void initializeMTU34(void);

void Inverter_initialize(void) {
    initializeS12AD0();
    initializeS12AD1();
    initializeADCMP();
    initializePOE();
    initializeMTU34();
}

static void initializeS12AD0(void) {
    MSTP_S12AD0 = 0; /* wakeup 12-bit ADC0 */
    PORT4.ICR.BYTE &= ~(0x0F); /* P40-P43 disable input buffer */
    ICU.IER[IER_S12AD0_S12ADI0].BIT.IEN6 = 0; /* disable S12AD0 interrupt in ICU */
    S12AD0.ADCSR.BYTE = 0x00; /* reset ADCSR */
    S12AD0.ADANS.WORD = 0x0000;
    S12AD0.ADCER.WORD = 0x0000;

    S12AD0.ADANS.BIT.PG000EN = 1; /* enable AN000 programmable gain amplifier */
    S12AD0.ADANS.BIT.PG001EN = 1; /* enable AN001 programmable gain amplifier */
    S12AD0.ADANS.BIT.PG002EN = 0; /* disable AN002 programmable gain amplifier */
    S12AD0.ADANS.BIT.PG000SEL = 1; /* AN000 programmable gain amplifier used */
    S12AD0.ADANS.BIT.PG001SEL = 1; /* AN001 programmable gain amplifier used */
    S12AD0.ADANS.BIT.PG002SEL = 0; /* AN002 Programmable gain amplifier not used (bypassed) */
    S12AD0.ADANS.BIT.CH = 3; /* channel set AN000-AN003 */

    S12AD0.ADSTRGR.BIT.ADSTRS0 = 5; /* Compare match/input capture in MTU4.TGRA, or MTU4.TCNT underflow in complementary PWM mode (trough) */
    S12AD0.ADSTRGR.BIT.ADSTRS1 = 5; /* Compare match/input capture in MTU4.TGRA, or MTU4.TCNT underflow in complementary PWM mode (trough) */

    S12AD0.ADPG.BIT.PG000GAIN = 9; /* x5.0 */
    S12AD0.ADPG.BIT.PG001GAIN = 9; /* x5.0 */
    S12AD0.ADPG.BIT.PG002GAIN = 2; /* x2.0 */

    S12AD0.ADCSR.BIT.EXTRG = 0; /* select timer trigger */
    S12AD0.ADCSR.BIT.TRGE = 1; /* enable ADTRG1#, MTU3 or GPT trigger  */
    S12AD0.ADCSR.BIT.CKS = 3; /* select PCLK */
    S12AD0.ADCSR.BIT.ADIE = 1; /* enable S12ADI0 interrupt on conversion complete */
    S12AD0.ADCSR.BIT.ADCS = 1; /* single cycle scan mode */
    S12AD0.ADCSR.BIT.ADST = 0; /* stop ADC */
}

static void initializeS12AD1(void) {
    MSTP_S12AD1 = 0; /* wakeup 12-bit ADC1 */
    PORT4.ICR.BYTE &= ~(0xF0); /* P44-P47 disable input buffer */
    ICU.IER[IER_S12AD1_S12ADI1].BIT.IEN7 = 0; /* disable S12AD1 interrupt in ICU */
    S12AD1.ADCSR.BYTE = 0x00; /* reset ADCSR */
    S12AD1.ADANS.WORD = 0x0000;
    S12AD1.ADCER.WORD = 0x0000;

    S12AD1.ADANS.BIT.PG100EN = 0; /* disable AN100 programmable gain amplifier */
    S12AD1.ADANS.BIT.PG101EN = 0; /* disable AN101 programmable gain amplifier */
    S12AD1.ADANS.BIT.PG102EN = 1; /* enable AN102 programmable gain amplifier */
    S12AD1.ADANS.BIT.PG100SEL = 0; /* AN100 programmable gain amplifier not used (bypassed) */
    S12AD1.ADANS.BIT.PG101SEL = 0; /* AN101 programmable gain amplifier not used (bypassed) */
    S12AD1.ADANS.BIT.PG102SEL = 1; /* AN102 Programmable gain amplifier used */
    S12AD1.ADANS.BIT.CH = 3; /* channel set AN100-AN103 */

    S12AD1.ADSTRGR.BIT.ADSTRS0 = 5; /* Compare match/input capture in MTU4.TGRA, or MTU4.TCNT underflow in complementary PWM mode (trough) */
    S12AD1.ADSTRGR.BIT.ADSTRS1 = 5; /* Compare match/input capture in MTU4.TGRA, or MTU4.TCNT underflow in complementary PWM mode (trough) */

    S12AD1.ADPG.BIT.PG100GAIN = 0; /* x2.0 */
    S12AD1.ADPG.BIT.PG101GAIN = 0; /* x2.0 */
    S12AD1.ADPG.BIT.PG102GAIN = 9; /* x5.0 */

    S12AD1.ADCSR.BIT.EXTRG = 0; /* select timer trigger */
    S12AD1.ADCSR.BIT.TRGE = 1; /* enable ADTRG1#, MTU3 or GPT trigger  */
    S12AD1.ADCSR.BIT.CKS = 3; /* select PCLK */
    S12AD1.ADCSR.BIT.ADIE = 0; /* disable S12ADI0 interrupt on conversion complete */
    S12AD1.ADCSR.BIT.ADCS = 1; /* single cycle scan mode */
    S12AD1.ADCSR.BIT.ADST = 0; /* stop ADC */
}

static void initializeADCMP(void) {
    MSTP_S12AD = 0;/* wakeup 12-bit ADC Control section */
    ICU.IER[IER_CMPB_CMPI].BIT.IEN_CMPB_CMPI = 0; /* disable CMPI interrupt in ICU */
    S12AD.ADCMPMD0.WORD = 0x0000; /* reset ADCMPMD0 */

    S12AD.ADCMPMD1.BIT.REFL = 1; /* low reference AVCC0 x 1/8 */
    S12AD.ADCMPMD1.BIT.REFH = 7; /* high reference AVCC0 x 7/8 */
    S12AD.ADCMPMD1.BIT.CSEL0 = 1; /* AN000-AN002 select signal after amplified */
    S12AD.ADCMPMD1.BIT.VSELH0 = 1; /* AN000-AN002 select internal reference signal */
    S12AD.ADCMPMD1.BIT.VSELL0 = 1; /* AN000-AN002 select internal reference signal */
    S12AD.ADCMPMD1.BIT.CSEL1 = 1; /* AN100-AN102 select signal after amplified */
    S12AD.ADCMPMD1.BIT.VSELH1 = 1; /* AN100-AN102 select internal reference signal */
    S12AD.ADCMPMD1.BIT.VSELL1 = 1; /* AN100-AN102 select internal reference signal */

    S12AD.ADCMPNR0.BIT.C000NR = 8; /* sampled 16 times with PCLK */
    S12AD.ADCMPNR0.BIT.C001NR = 8; /* sampled 16 times with PCLK */
    S12AD.ADCMPNR0.BIT.C002NR = 0; /* not sampled */

    S12AD.ADCMPNR1.BIT.C100NR = 0; /* not sampled */
    S12AD.ADCMPNR1.BIT.C101NR = 0; /* not sampled */
    S12AD.ADCMPNR1.BIT.C102NR = 8; /* sampled 16 times with PCLK */

    S12AD.ADCMPSEL.BIT.SEL000 = 1; /* use as CMPI interrupt or POE request */
    S12AD.ADCMPSEL.BIT.SEL001 = 1; /* use as CMPI interrupt or POE request */
    S12AD.ADCMPSEL.BIT.SEL002 = 0; /* do not use as CMPI interrupt or POE request */
    S12AD.ADCMPSEL.BIT.SEL100 = 0; /* do not use as CMPI interrupt or POE request */
    S12AD.ADCMPSEL.BIT.SEL101 = 0; /* do not use as CMPI interrupt or POE request */
    S12AD.ADCMPSEL.BIT.SEL102 = 1; /* use as CMPI interrupt or POE request */
    S12AD.ADCMPSEL.BIT.IE = 1; /* enable CMPI interrupt*/
    S12AD.ADCMPSEL.BIT.POERQ = 1; /* enable POE request*/

    S12AD.ADCMPMD0.BIT.CEN000 = 3; /* enable AN000 window comparator */
    S12AD.ADCMPMD0.BIT.CEN001 = 3; /* enable AN001 window comparator */
    S12AD.ADCMPMD0.BIT.CEN002 = 0; /* disable AN002 comparator */
    S12AD.ADCMPMD0.BIT.CEN100 = 0; /* disable AN100 comparator */
    S12AD.ADCMPMD0.BIT.CEN101 = 0; /* disable AN101 comparator */
    S12AD.ADCMPMD0.BIT.CEN102 = 3; /* enable AN102 window comparator */

    S12AD.ADCMPFR.BYTE = 0x00; /* clear comparator detection flag before enabling interrupts */
}

static void initializePOE(void) {
    ICU.IER[IER_POE_OEI1].BIT.IEN_POE_OEI1 = 0; /* disable OEI interrupt in ICU */

    POE.POECR4.BIT.CMADDMT34ZE = 1; /* add MTU CH34 high-impedance CFLAG */

    POE.OCSR1.BIT.OCE1 = 1; /* enable MTU CH34 output short high-impedance */
    POE.OCSR1.BIT.OIE1 = 1; /* enable MTU CH34 output short interrupt */

    POE.POECR2.BIT.MTU4BDZE = 1; /* enable high-impedance */
    POE.POECR2.BIT.MTU4ACZE = 1; /* enable high-impedance */
    POE.POECR2.BIT.MTU3BDZE = 1; /* enable high-impedance */
}

static void initializeMTU34(void) {
    MSTP_MTU = 0; /* wakeup MTU */
    PORT7.ICR.BYTE &= ~(0x7E); /* P71-P76 disable input buffer */
    PORT7.DDR.BYTE &= ~(0x7E); /* P71-P76 select input pin */
    MTU.TOERA.BYTE = 0xC0; /* disable pwm output */

    MTU.TRWERB.BIT.RWE = 1; /* MTU registers writing enable */

    MTU.TSTRA.BIT.CST4 = 0; /* channel 4 TCNT disable */
    MTU.TSTRA.BIT.CST3 = 0; /* channel 3 TCNT disable */

    MTU3.TCR.BIT.TPSC = 0; /* select time prescaler ICLK/1 */
    MTU3.TCR.BIT.CKEG = 0; /* count at rising edge */
    MTU3.TCR.BIT.CCLR = 0; /* disable TCNT clearing */

    MTU4.TCR.BIT.TPSC = 0; /* select time prescaler ICLK/1 */
    MTU4.TCR.BIT.CKEG = 0; /* count at rising edge */
    MTU4.TCR.BIT.CCLR = 0; /* disable TCNT clearing */

    MTU.TGCRA.BYTE = 0x00;  /* disable functions of TGCRA */

    MTU3.TCNT = DEADTIME; /* starts up-counting from the value set in the dead time register */
    MTU4.TCNT = 0; /* starts up-counting after being initialized to 0000h */

    MTU.TSYRA.BIT.SYNC3 = 0;  /* MTU3.TCNT operates independently */
    MTU.TSYRA.BIT.SYNC4 = 0;  /* MTU4.TCNT operates independently */

    MTU3.TGRB = HALF_PERIOD_AND_DEADTIME; /* initialize PWM output 1 compare register */
    MTU4.TGRA = HALF_PERIOD_AND_DEADTIME; /* initialize PWM output 2 compare register */
    MTU4.TGRB = HALF_PERIOD_AND_DEADTIME; /* initialize PWM output 3 compare register */
    MTU3.TGRD = HALF_PERIOD_AND_DEADTIME; /* initialize MTU3.TGRB buffer */
    MTU4.TGRC = HALF_PERIOD_AND_DEADTIME; /* initialize MTU4.TGRA buffer */
    MTU4.TGRD = HALF_PERIOD_AND_DEADTIME; /* initialize MTU4.TGRD buffer */

    MTU.TDERA.BIT.TDER = 1; /* generate deadtime */

    MTU.TDDRA = DEADTIME; /* deadtime */
    MTU.TCDRA = HALF_PERIOD; /* half pwm period in TCDR */
    MTU.TCBRA = HALF_PERIOD; /* MTU.TCDRA buffer */
    MTU3.TGRA = HALF_PERIOD_AND_DEADTIME; /* set MTU3.TCNT upper limit value */
    MTU3.TGRC = HALF_PERIOD_AND_DEADTIME; /* MTU3.TGRA buffer */

    MTU.TOCR1A.BIT.OLSP = 1; /* select high-active output level */
    MTU.TOCR1A.BIT.OLSN = 1; /* select high-active output level */
    MTU.TOCR1A.BIT.TOCS = 0; /* select TOCR1A setting */
    MTU.TOCR1A.BIT.TOCL = 0; /* enable write access to TOCS, OLSN and OLSP */
    MTU.TOCR1A.BIT.PSYE = 0; /* disable toggle output */

    MTU3.TMDR1.BIT.MD = 0x0E; /* complementary PWM mode 1 (transfer at trough) */
    MTU3.TMDR1.BIT.BFA = 1; /* TGRA and TGRC used together for buffer operation */
    MTU3.TMDR1.BIT.BFB = 1; /* TGRB and TGRD used together for buffer operation */

    MTU4.TMDR1.BIT.MD = 0; /* Normal operation */
    MTU4.TMDR1.BIT.BFA = 0; /* TGRA and TGRC operate normally */
    MTU4.TMDR1.BIT.BFB = 0; /* TGRB and TGRD operate normally */

    MTU.TMDR2A.BIT.DRS = 0; /* disable double buffer function */

    MTU4.TIER.BIT.TTGE2 = 1; /* enable A/D trigger at TCNT4 underflow (trough) */
}

void Inverter_initializeInterrupt(uint8_t priority) {
    ICU.IPR[IPR_S12AD0_S12ADI0].BIT.IPR = priority;
}

void Inverter_enableInterrupt(void) {
    ICU.IER[IER_S12AD0_S12ADI0].BIT.IEN_S12AD0_S12ADI0 = 1;
}

void Inverter_disableInterrrupt(void) {
    ICU.IER[IER_S12AD0_S12ADI0].BIT.IEN_S12AD0_S12ADI0 = 0; /* disable S12AD0 interrupt in ICU */
}

void Inverter_startTimer(void) {
    MTU.TSTRA.BYTE |= 0xC0; /* start simultaneously MTU3.TCNT and MTU4.TCNT */
}

void Inverter_stopTimer(void) {
    MTU.TSTRA.BYTE &= ~(0xC0); /* stop simultaneously MTU3.TCNT and MTU4.TCNT */
}

bool Inverter_isTimerStarted(void) {
    return ((MTU.TSTRA.BYTE & 0xC0) != 0);
}

void Inverter_enableOutput(void) {
    MTU.TOERA.BYTE = 0xFF;
}

void Inverter_disableOutput(void) {
    MTU.TOERA.BYTE = 0xC0;
    PORT7.DR.BYTE &= ~(0x7E);
}

bool Inverter_isOutput(void) {
    return (MTU.TOERA.BYTE == 0xFF);
}

bool Inverter_hasError(void) {
    return (POE.OCSR1.BIT.OSF1 != 0) | ((S12AD.ADCMPFR.BYTE & 0x23) != 0);
}

void Inverter_clearError(void) {
    POE.OCSR1.BIT.OSF1 = 0;
    ICU.IR[IR_POE_OEI1].BIT.IR = 0;
    S12AD.ADCMPFR.BYTE &= ~0x23;
    ICU.IR[IR_CMPB_CMPI].BIT.IR = 0;
}

void Inverter_setPWMReference(float u, float v, float w) {
    uint16_t counterMax;
    int32_t duty;

    counterMax = MTU3.TGRA;

    duty = (uint32_t)((-(int32_t)(u * (float)counterMax)) + counterMax) / 2;
    duty = (duty > counterMax) ? counterMax:
           (duty < 0) ? 0:
           /*else*/ duty;
    MTU3.TGRD = (uint16_t)duty;

    duty = (uint32_t)((-(int32_t)(v * (float)counterMax)) + counterMax) / 2;
    duty = (duty > counterMax) ? counterMax:
           (duty < 0) ? 0:
           /*else*/ duty;
    MTU4.TGRC = (uint16_t)duty;

    duty = (uint32_t)((-(int32_t)(w * (float)counterMax)) + counterMax) / 2;
    duty = (duty > counterMax) ? counterMax:
           (duty < 0) ? 0:
           /*else*/ duty;
    MTU4.TGRD = (uint16_t)duty;
}
