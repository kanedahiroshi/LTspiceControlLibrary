#ifndef _Inverter
#define _Inverter

#include <iodefine.h>
#include <stdbool.h>
#include <stdint.h>

#define Inverter_CARRIER_FREQUENCY_HZ   10000
#define Inverter_DEADTIME_S   (3.0e-6f)
#define Inverter_TIMER_CLOCK_HZ   MCUIO_SYSTEM_CLOCK_HZ
#define Inverter_INTERRUPT_FREQUENCY_HZ   Inverter_CARRIER_FREQUENCY_HZ
#define Inverter_DELTA_PWM_REFERENCE_PER_TIME   (1.0f / (1.0f / (2 * Inverter_CARRIER_FREQUENCY_HZ) + Inverter_DEADTIME_S))

void Inverter_initialize(void);
void Inverter_initializeInterrupt(uint8_t priority);
void Inverter_enableInterrupt(void);
void Inverter_disableInterrrupt(void);
void Inverter_startTimer(void);
void Inverter_stopTimer(void);
bool Inverter_isTimerStarted(void);
void Inverter_enableOutput(void);
void Inverter_disableOutput(void);
bool Inverter_isOutput(void);
bool Inverter_hasError(void);
void Inverter_clearError(void);
void Inverter_setPWMReference(float u, float v, float w);

#define Inverter_getIuRaw()   (S12AD0.ADDR0A)
#define Inverter_getIwRaw()   (S12AD0.ADDR1)
#define Inverter_getVpnRaw()   (S12AD0.ADDR2)
#define Inverter_getVunRaw()   (S12AD0.ADDR3)
#define Inverter_getVvnRaw()   (S12AD1.ADDR0A)
#define Inverter_getVwnRaw()   (S12AD1.ADDR1)
#define Inverter_getIvRaw()   (S12AD1.ADDR2)
#define Inverter_getVr1Raw()   (S12AD1.ADDR3)

#define Inverter_getIu()   (-(22.2005f / 4095.0f) * (Inverter_getIuRaw() - 2047))
#define Inverter_getIw()   (-(22.2005f / 4095.0f) * (Inverter_getIwRaw() - 2047))
#define Inverter_getVpn()   ((55.0f / 4095.0f) * Inverter_getVpnRaw())
#define Inverter_getVun()   ((55.0f / 4095.0f) * Inverter_getVunRaw())
#define Inverter_getVvn()   ((55.0f / 4095.0f) * Inverter_getVvnRaw())
#define Inverter_getVwn()   ((55.0f / 4095.0f) * Inverter_getVwnRaw())
#define Inverter_getIv()   (-(22.2005f / 4095.0f) * (Inverter_getIvRaw() - 2047))
#define Inverter_getVr1()   ((5.0f / 4095.0f) * Inverter_getVr1Raw())

#endif /* _Inverter */
