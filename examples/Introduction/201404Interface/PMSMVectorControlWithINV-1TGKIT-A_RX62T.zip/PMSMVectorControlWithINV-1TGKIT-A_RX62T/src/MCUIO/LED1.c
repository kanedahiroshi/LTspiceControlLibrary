#include "LED1.h"
#include <iodefine.h>

void LED1_initialize(void) {
    _LED1_PORT.ICR.BIT._LED1_BIT = 0;
    _LED1_PORT.DR.BIT._LED1_BIT = !_LED1_ACTIVE_LOGIC;
    _LED1_PORT.DDR.BIT._LED1_BIT = 1;
}
