#ifndef _LED1
#define _LED1

#include <iodefine.h>

#define _LED1_PORT   PORTA
#define _LED1_BIT   B2
#define _LED1_ACTIVE_LOGIC   0

#define _LED1_DR   _LED1_PORT.DR.BIT._LED1_BIT

void LED1_initialize(void);
#define LED1_turnOn()   (_LED1_DR = _LED1_ACTIVE_LOGIC)
#define LED1_turnOff()   (_LED1_DR = !_LED1_ACTIVE_LOGIC)
#define LED1_turnOver()   (_LED1_DR ^= 1)
#define LED1_isOn()   (_LED1_DR == _LED1_ACTIVE_LOGIC)

#endif /* _LED1 */
