#include "LED2.h"
#include <iodefine.h>

void LED2_initialize(void) {
    _LED2_PORT.ICR.BIT._LED2_BIT = 0;
    _LED2_PORT.DR.BIT._LED2_BIT = !_LED2_ACTIVE_LOGIC;
    _LED2_PORT.DDR.BIT._LED2_BIT = 1;
}
