#ifndef _LED2
#define _LED2

#include <iodefine.h>

#define _LED2_PORT   PORTA
#define _LED2_BIT   B3
#define _LED2_ACTIVE_LOGIC   0

#define _LED2_DR   _LED2_PORT.DR.BIT._LED2_BIT

void LED2_initialize(void);
#define LED2_turnOn()   (_LED2_DR = _LED2_ACTIVE_LOGIC)
#define LED2_turnOff()   (_LED2_DR = !_LED2_ACTIVE_LOGIC)
#define LED2_turnOver()   (_LED2_DR ^= 1)
#define LED2_isOn()   (_LED2_DR == _LED2_ACTIVE_LOGIC)

#endif /* _LED2 */
