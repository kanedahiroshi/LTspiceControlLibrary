#include "LED3.h"
#include <iodefine.h>

void LED3_initialize(void) {
    _LED3_PORT.ICR.BIT._LED3_BIT = 0;
    _LED3_PORT.DR.BIT._LED3_BIT = !_LED3_ACTIVE_LOGIC;
    _LED3_PORT.DDR.BIT._LED3_BIT = 1;
}
