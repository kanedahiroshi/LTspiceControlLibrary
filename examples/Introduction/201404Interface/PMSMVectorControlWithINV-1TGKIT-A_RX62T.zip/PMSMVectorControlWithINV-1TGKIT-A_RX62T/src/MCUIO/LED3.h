#ifndef _LED3
#define _LED3

#include <iodefine.h>

#define _LED3_PORT   PORTB
#define _LED3_BIT   B0
#define _LED3_ACTIVE_LOGIC   0

#define _LED3_DR   _LED3_PORT.DR.BIT._LED3_BIT

void LED3_initialize(void);
#define LED3_turnOn()   (_LED3_DR = _LED3_ACTIVE_LOGIC)
#define LED3_turnOff()   (_LED3_DR = !_LED3_ACTIVE_LOGIC)
#define LED3_turnOver()   (_LED3_DR ^= 1)
#define LED3_isOn()   (_LED3_DR == _LED3_ACTIVE_LOGIC)

#endif /* _LED3 */
