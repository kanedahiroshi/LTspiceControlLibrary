#include "LED4.h"
#include <iodefine.h>

void LED4_initialize(void) {
    _LED4_PORT.ICR.BIT._LED4_BIT = 0;
    _LED4_PORT.DR.BIT._LED4_BIT = !_LED4_ACTIVE_LOGIC;
    _LED4_PORT.DDR.BIT._LED4_BIT = 1;
}
