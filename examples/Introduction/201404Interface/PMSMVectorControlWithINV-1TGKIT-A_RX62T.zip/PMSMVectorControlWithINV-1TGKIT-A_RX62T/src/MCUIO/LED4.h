#ifndef _LED4
#define _LED4

#include <iodefine.h>

#define _LED4_PORT   PORTB
#define _LED4_BIT   B3
#define _LED4_ACTIVE_LOGIC   0

#define _LED4_DR   _LED4_PORT.DR.BIT._LED4_BIT

void LED4_initialize(void);
#define LED4_turnOn()   (_LED4_DR = _LED4_ACTIVE_LOGIC)
#define LED4_turnOff()   (_LED4_DR = !_LED4_ACTIVE_LOGIC)
#define LED4_turnOver()   (_LED4_DR ^= 1)
#define LED4_isOn()   (_LED4_DR == _LED4_ACTIVE_LOGIC)

#endif /* _LED4 */
