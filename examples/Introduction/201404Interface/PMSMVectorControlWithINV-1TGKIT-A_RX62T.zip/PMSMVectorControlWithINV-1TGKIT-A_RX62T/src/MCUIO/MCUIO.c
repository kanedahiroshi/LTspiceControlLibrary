#include "MCUIO.h"
#include <iodefine.h>

void MCUIO_initialize(void) {
    SYSTEM.SCKCR.BIT.ICK = 0x00; /* ICLK : EXTAL×8 */
    SYSTEM.SCKCR.BIT.PCK = 0x01; /* PCLK : EXTAL×4 */
}
