#ifndef _MCUIO
#define _MCUIO

#include <machine.h>

#define MCUIO_EXTERNAL_CLOCK_HZ   12000000
#define MCUIO_SYSTEM_CLOCK_HZ   (MCUIO_EXTERNAL_CLOCK_HZ * 8)
#define MCUIO_PERIPHERAL_CLOCK_HZ   (MCUIO_EXTERNAL_CLOCK_HZ * 4)

#define MCUIO_enableGlobalInterrupt()   setpsw_i()
#define MCUIO_disableGlobalInterrupt()   clrpsw_i()
#define MCUIO_isGlobalInterruptEnabled()   ((get_psw() & (1UL << 16)) != 0)

#define MCUIO_sleep()   wait()

void MCUIO_initialize(void);

#endif /* _MCUIO */
