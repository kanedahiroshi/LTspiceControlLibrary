#include "SW1.h"
#include <iodefine.h>
#include <stdint.h>

void SW1_initialize(void) {
    _SW1_PORT.ICR.BIT._SW1_BIT = 1;
    _SW1_PORT.DDR.BIT._SW1_BIT = 0;
}

#if _SW1_HAS_INTERRUPT_FUNCTION
void SW1_initializeInterrupt(uint8_t priority, uint8_t mode) {
    SW1_disableInterrupt();
    SW1_clearInterruptRequest();
    _SW1_IPR = priority;
    _SW1_selectPinAsIRQ();
    ICU.IRQCR[_SW1_IRQ].BIT.IRQMD = mode;
}
#endif /* _SW1_HAS_INTERRUPT_FUNCTION */
