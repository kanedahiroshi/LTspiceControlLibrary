#ifndef _SW1
#define _SW1

#include <iodefine.h>
#include <stdint.h>

#define _SW1_PORT   PORT9
#define _SW1_BIT   B1
#define _SW1_ACTIVE_LOGIC   0

void SW1_initialize(void);
#define SW1_isOn()   (_SW1_PORT.PORT.BIT._SW1_BIT == _SW1_ACTIVE_LOGIC)

#define _SW1_HAS_INTERRUPT_FUNCTION   0
#if _SW1_HAS_INTERRUPT_FUNCTION
#include "IRQ.h"
#define _SW1_IRQ   0
#define _SW1_IR   IR(ICU, IRQ0)
#define _SW1_IPR   IPR(ICU, IRQ0)
#define _SW1_IEN   IEN(ICU, IRQ0)
#define _SW1_selectPinAsIRQ()   (IOPORT.PF8IRQ.BIT.ITS0 = 1)

void SW1_initializeInterrupt(uint8_t priority, uint8_t mode);
#define SW1_enableInterrupt()   (_SW1_IEN = 1)
#define SW1_disableInterrupt()   (_SW1_IEN = 0)
#define SW1_isInterruptEnabled()   (_SW1_IEN != 0)
#define SW1_clearInterruptRequest()   (_SW1_IR = 0)
#define SW1_isInterruptRequested()   (_SW1_IR != 0)
#endif /* _SW1_HAS_INTERRUPT_FUNCTION */

#endif /* _SW1 */
