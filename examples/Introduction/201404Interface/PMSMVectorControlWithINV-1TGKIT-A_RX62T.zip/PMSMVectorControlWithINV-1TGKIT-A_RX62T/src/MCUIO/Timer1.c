#include "Timer1.h"
#include <stdint.h>

void Timer1_initialize(float frequency) {
    _Timer1_MSTP = 0; /* wakeup CMT */
    Timer1_stop();
    Timer1_setCount(0);
    _Timer1_CMT.CMCR.BIT.CKS = _Timer1_CLOCK_DIVIDING_FACTOR;
    _Timer1_CMT.CMCOR = (uint16_t)((Timer1_CLOCK_HZ / frequency) - 1);
}

void Timer1_initializeInterrupt(uint8_t priority) {
    Timer1_disableInterrupt();
    Timer1_clearInterruptRequest();
    _Timer1_IPR = priority;
    _Timer1_CMT.CMCR.BIT.CMIE = 1; /* enable compare match interrupt */
}
