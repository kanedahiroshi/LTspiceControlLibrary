#ifndef _Timer1
#define _Timer1

#include <iodefine.h>
#include <stdint.h>
#include "MCUIO.h"

#define _Timer1_MSTP   MSTP_CMT1
#define _Timer1_CMT   CMT1
#define _Timer1_STR   (CMT.CMSTR0.BIT.STR1)
#define _Timer1_IR   IR(CMT1, CMI1)
#define _Timer1_IPR   IPR(CMT1, CMI1)
#define _Timer1_IEN   IEN(CMT1, CMI1)

#define _Timer1_CLOCK_DIVIDING_FACTOR   2 /* 0 to 3 */
#define Timer1_CLOCK_HZ   (MCUIO_PERIPHERAL_CLOCK_HZ / (8 << (2 * _Timer1_CLOCK_DIVIDING_FACTOR)))
#define Timer1_COUNT_MAX   (UINT16_MAX)

void Timer1_initialize(float frequency);
#define Timer1_start()   (_Timer1_STR = 1)
#define Timer1_stop()   (_Timer1_STR = 0)
#define Timer1_getCount()   (_Timer1_CMT.CMCNT)
#define Timer1_setCount(value)   (_Timer1_CMT.CMCNT = (value))

void Timer1_initializeInterrupt(uint8_t priority);
#define Timer1_enableInterrupt()   (_Timer1_IEN = 1)
#define Timer1_disableInterrupt()   (_Timer1_IEN = 0)
#define Timer1_isInterruptEnabled()   (_Timer1_IEN != 0)
#define Timer1_clearInterruptRequest()   (_Timer1_IR = 0)
#define Timer1_isInterruptRequested()   (_Timer1_IR != 0)

#endif /* _Timer1 */
