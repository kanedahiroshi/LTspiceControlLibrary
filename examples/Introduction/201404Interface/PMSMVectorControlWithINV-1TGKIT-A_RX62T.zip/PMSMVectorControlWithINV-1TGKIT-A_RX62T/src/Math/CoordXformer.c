#include "CoordXformer.h"
#include "altmath.h"
#include <math.h>

void CoordXformer_rotateXy(float x1, float y1, float p, float *x2, float *y2) {
    float sinp = sinf(p);
    float cosp = cosf(p);
    *x2 = x1 * cosp - y1 * sinp;
    *y2 = x1 * sinp + y1 * cosp;
}

void CoordXformer_transformAbToUvw(float a, float b, float *u, float *v, float *w) {
    *u = (M_SQRT2 / M_SQRT3) * a;
    *w = (1.0f / (M_SQRT2 * M_SQRT3)) * (-a -M_SQRT3 * b);
    *v = -*u - *w;
}

void CoordXformer_transformUwToAb(float u, float w, float *a, float *b) {
    *a = (M_SQRT3 * M_SQRT1_2) * u;
    *b = M_SQRT1_2 * (-u - 2 * w);
}
