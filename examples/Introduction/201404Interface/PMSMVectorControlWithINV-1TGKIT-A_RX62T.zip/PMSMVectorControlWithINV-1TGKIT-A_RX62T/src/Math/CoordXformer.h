#ifndef _CoordXformer
#define _CoordXformer

void CoordXformer_rotateXy(float x1, float y1, float p, float *x2, float *y2);
void CoordXformer_transformAbToUvw(float a, float b, float *u, float *v, float *w);
void CoordXformer_transformUwToAb(float u, float w, float *a, float *b);

#endif /* _CoordXformer */
