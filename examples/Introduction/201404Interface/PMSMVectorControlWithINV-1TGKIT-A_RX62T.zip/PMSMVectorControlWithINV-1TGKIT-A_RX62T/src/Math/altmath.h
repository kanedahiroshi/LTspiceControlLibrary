/* alternative math library for C standard library */
#ifndef _ALTMATH
#define _ALTMATH

#define M_PI   3.14159265358979323846f
#define M_SQRT2   1.41421356237309504880f
#define M_SQRT3   1.73205080756887729352f
#define M_SQRT1_2   0.70710678118654752440f

#pragma inline(fdim)
static double fdim(double x, double y) { return x > y ? (x - y) : 0; }
#pragma inline(fmin)
static double fmin(double x, double y) { return x < y ? x : y; }
#pragma inline(fmax)
static double fmax(double x, double y) { return x > y ? x : y; }

#pragma inline(fdimf)
static float fdimf(float x, float y) { return x > y ? (x - y) : 0; }
#pragma inline(fminf)
static float fminf(float x, float y) { return x < y ? x : y; }
#pragma inline(fmaxf)
static float fmaxf(float x, float y) { return x > y ? x : y; }

#endif /* _ALTMATH */
