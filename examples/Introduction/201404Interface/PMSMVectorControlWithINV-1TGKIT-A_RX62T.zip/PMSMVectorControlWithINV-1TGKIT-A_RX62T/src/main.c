/*****************************************************************************
    PMSM Vector Control with Hall Sensor

    Bord: INV-1TGKIT-A
    MCU: RX62T (R5F562T6AxFM)
    Motor: BLY171S-15V-8000 (U: Yellow, V: Red, W: Black)

    SW1: run/stop switch (P91)
    VR1: speed reference volume (AN103)
    LED1(green): run/stop indicator (PA2)
    LED2(green): alive indicator of main loop (PA3)
    LED3(green): alive indicator of inverter ISR (PB0)
    LED4(red): error indicator (PB3)
    RESET: MCU hard reset switch (RES#)
    CN4: hall sensor (U: P10(IRQ0), V: P11(IRQ1), W: PB4(IRQ3))
    U, V, W: motor wires
*****************************************************************************/

#include "main.h"
#include "ICS/ICS_RX62T.h"
#include "Math/altmath.h"
#include "Math/CoordXformer.h"
#include "MCUIO/HallSensor.h"
#include "MCUIO/Inverter.h"
#include "MCUIO/LED1.h"
#include "MCUIO/LED2.h"
#include "MCUIO/LED3.h"
#include "MCUIO/LED4.h"
#include "MCUIO/MCUIO.h"
#include "MCUIO/SW1.h"
#include "MCUIO/Timer1.h"
#include <math.h>
#include <stdbool.h>
#include <stdint.h>

/*****************************************************************************
    Function Declarations
*****************************************************************************/
static void initialize(void);
static void initializeVariable(void);
static void loop(void);
static void blinkLED2(void);
static void blinkLED3(void);
static void watchICS(void);
static void sumCapturedCount(uint16_t lastValue);

#define Timer1_isOverflowed()   Timer1_isInterruptRequested()
#define Timer1_clearOverflow()   Timer1_clearInterruptRequest()

/*****************************************************************************
    Variable Definitions
*****************************************************************************/
/* interrupt priority level 0 （interrupt prohibited） to 15 （highest) */
#define INTERRUPT_PRIORITY_INVERTER   10
#define INTERRUPT_PRIORITY_HALL_SENSOR   12
#define INTERRUPT_PRIORITY_TIMER1   0 /* interrupt prohibited. only use interrupt request flag as overflow flag */
#define INTERRUPT_PRIORITY_ICS   6

#pragma section DTCTBL
uint32_t dtcTable[256]; /* DTC vector table area */
#pragma section

/*---------------------------------------------------------------------------
    Control Parameters
---------------------------------------------------------------------------*/
float motorKe = 0.015f / M_SQRT2 / 4;
int8_t motorNp = 4;

float omLimit = 8000.0f * (2.0f * M_PI / 60.0f) * 1.1f;

float offsetPositon = 0.65f;

float kpOm = 0.00036f;
float kiOm = 0.0024f;
float wpOm = 0.7f;
float tmLimit = 31.0e-3f * 1.5;

float controlThresholdOm = 45.0f;
float controlHysteresisOm = 10.0f;

float idRefOpen = 1.0f;
float openLoopOmStep = 0.1f;

float iuOffset = -0.13265716f;
float iwOffset = -0.10555032f;
float ivOffset = -0.143499896f;

float kpId = 1.0f;
float kiId = 0.08f;
float kpIq = 1.0f;
float kiIq = 0.08f;
float vdqLimitFactor = M_SQRT3 / M_SQRT2 * 0.5f;

float mUpperLimit = 1.0f - ((1.0e-6f + 2 * Inverter_DEADTIME_S) * Inverter_DELTA_PWM_REFERENCE_PER_TIME);

/*---------------------------------------------------------------------------
    Sequence Node Variables
---------------------------------------------------------------------------*/
bool isRunRequest = false;
float omRequest = 0.0f;

#define UI_BORD   0
#define UI_ICS   1
uint8_t uiRequest = UI_BORD;

bool isRunning = false;

#define CONTROL_MODE_OPEN   0
#define CONTROL_MODE_SPEED 1
uint8_t controlMode = CONTROL_MODE_OPEN;

/*---------------------------------------------------------------------------
    Control Node Variables
---------------------------------------------------------------------------*/
uint8_t hallU;
uint8_t hallV;
uint8_t hallW;
uint8_t previousHall = HallSensor_NONE;

uint16_t capturedCount = Timer1_COUNT_MAX;
int8_t basePosition = 0;
bool isCCW = false;
#define CAPTURED_COUNT_BUFFER_LENGTH 3
uint16_t capturedCountBuffer[CAPTURED_COUNT_BUFFER_LENGTH] = { Timer1_COUNT_MAX };
int8_t capturedCountIndex = 0;
int32_t capturedCountSum = Timer1_COUNT_MAX;

float pe = 0.0f;
float oe = 0.0f;
float om = 0.0f;
float sensedPe = 0.0f;
float sensedOe = 0.0f;
float sensedOm = 0.0f;

float omRef = 0.0f;
float tmRefP = 0.0f;
float tmRefI = 0.0f;
float tmRefPFw = 0.0f;
float tmRef = 0.0f;
float tmRefOver = 0.0f;

float iu = 0.0f;
float iw = 0.0f;
float vpn = 0.0f;
float vun = 0.0f;
float vvn = 0.0f;
float vwn = 0.0f;
float iv = 0.0f;
float vr1 = 0.0f;

float ia = 0.0f;
float ib = 0.0f;
float id = 0.0f;
float iq = 0.0f;

float idRef = 0.0f;
float iqRef = 0.0f;

float vdRefP = 0.0f;
float vdRefI = 0.0f;
float vqRefP = 0.0f;
float vqRefI = 0.0f;
float vdRef = 0.0f;
float vqRef = 0.0f;
float vdRefOver = 0.0f;
float vqRefOver = 0.0f;

float vaRef = 0.0f;
float vbRef = 0.0f;

float vuRef = 0.0f;
float vvRef = 0.0f;
float vwRef = 0.0f;

float muRef = 0.0f;
float mvRef = 0.0f;
float mwRef = 0.0f;

/*****************************************************************************
    Function Definitions
*****************************************************************************/
int main(void) {
    initialize();

    while (1) {
        loop();
    }
    /* NOTREACHED */
    return 0;
}

static void initialize(void)
{
    MCUIO_disableGlobalInterrupt();
    MCUIO_initialize();

    HallSensor_initialize();
    HallSensor_initializeInterruptU(INTERRUPT_PRIORITY_HALL_SENSOR, IRQ_MODE_BOTH_EDGES);
    HallSensor_initializeInterruptV(INTERRUPT_PRIORITY_HALL_SENSOR, IRQ_MODE_BOTH_EDGES);
    HallSensor_initializeInterruptW(INTERRUPT_PRIORITY_HALL_SENSOR, IRQ_MODE_BOTH_EDGES);
    Inverter_initialize();
    Inverter_initializeInterrupt(INTERRUPT_PRIORITY_INVERTER);
    LED1_initialize();
    LED2_initialize();
    LED3_initialize();
    LED4_initialize();
    SW1_initialize();
    Timer1_initialize(Timer1_CLOCK_HZ / (float)Timer1_COUNT_MAX);
    Timer1_initializeInterrupt(INTERRUPT_PRIORITY_TIMER1);

    ics_init(&dtcTable, ICS_SCI0_PB2_PB1, INTERRUPT_PRIORITY_ICS);

    initializeVariable();

    HallSensor_enableInterruptU();
    HallSensor_enableInterruptV();
    HallSensor_enableInterruptW();
    Inverter_enableInterrupt();
    Inverter_startTimer();
    Timer1_start();

    MCUIO_enableGlobalInterrupt();
}

static void initializeVariable(void) {
    int32_t i;
    hallU = HallSensor_isUOn();
    hallV = HallSensor_isVOn();
    hallW = HallSensor_isWOn();

    capturedCountSum = 0;
    for (i = 0; i < CAPTURED_COUNT_BUFFER_LENGTH; i++) {
        capturedCountBuffer[i] = Timer1_COUNT_MAX;
        capturedCountSum += Timer1_COUNT_MAX;
    }
}

static void loop(void) {
    if (uiRequest == UI_BORD) {
        isRunning = SW1_isOn();
        omRef = ((vr1 - 2.5f) / 2.5f) * omLimit;
    }
    else {
        isRunning = isRunRequest;
        omRef = fminf(fmaxf(omRequest, -omLimit), omLimit);
    }

    if (isRunning) {
        Inverter_enableOutput();
        LED1_turnOn();
    }
    else {
        Inverter_disableOutput();
        LED1_turnOff();
    }

    if (Inverter_hasError()) {
        LED4_turnOn();
    }
    else {
        LED4_turnOff();
    }

    blinkLED2();
}

static void blinkLED2(void) {
    static int32_t counter = 0;
    if (++counter >= 500000) {
        LED2_turnOver();
        counter = 0;
    }
}

void Interrupt_HallSensorU(void) {
    hallU = HallSensor_isUOn();
    if (previousHall == HallSensor_U) return;
    capturedCount = !Timer1_isOverflowed() ? Timer1_getCount() : Timer1_COUNT_MAX;
    Timer1_setCount(0);
    Timer1_clearOverflow();
    basePosition = ((hallV == 0) ? 0 : 3);
    isCCW = (hallU != hallV);
    previousHall = HallSensor_U;
    sumCapturedCount(capturedCount);
}

void Interrupt_HallSensorV(void) {
    hallV = HallSensor_isVOn();
    if (previousHall == HallSensor_V) return;
    capturedCount = !Timer1_isOverflowed() ? Timer1_getCount() : Timer1_COUNT_MAX;
    Timer1_setCount(0);
    Timer1_clearOverflow();
    basePosition = ((hallW == 0) ? 2 : 5);
    isCCW = (hallV != hallW);
    previousHall = HallSensor_V;
    sumCapturedCount(capturedCount);
}

void Interrupt_HallSensorW(void) {
    hallW = HallSensor_isWOn();
    if (previousHall == HallSensor_W) return;
    capturedCount = !Timer1_isOverflowed() ? Timer1_getCount() : Timer1_COUNT_MAX;
    Timer1_setCount(0);
    Timer1_clearOverflow();
    basePosition = ((hallU == 0) ? 4 : 1);
    isCCW = (hallW != hallU);
    previousHall = HallSensor_W;
    sumCapturedCount(capturedCount);
}

static void sumCapturedCount(uint16_t lastValue) {
    capturedCountSum += (int32_t)lastValue - (int32_t)capturedCountBuffer[capturedCountIndex];
    capturedCountBuffer[capturedCountIndex++] = lastValue;
    if (capturedCountIndex >= CAPTURED_COUNT_BUFFER_LENGTH) {
        capturedCountIndex = 0;
    }
}

void Interrupt_Inverter(void) {
    /* speed and angle calcurator for hall sensor */
    {
        int8_t basePositionHold =  basePosition;
        int32_t capturedCountSumHold = capturedCountSum;
        bool isCCWHold = isCCW;
        uint16_t currentCountHold = Timer1_getCount();
        bool isTimerOverFlowedHold = Timer1_isOverflowed();
        float position;
        float divCount;
        float deltaPosition;
        float absSensedOe;

    MCUIO_enableGlobalInterrupt(); /* enable nested interrupt */

        position = basePositionHold + offsetPositon;
        if (!isTimerOverFlowedHold) {
            divCount = (float)CAPTURED_COUNT_BUFFER_LENGTH / (float)capturedCountSumHold;
            deltaPosition = fminf(currentCountHold * divCount, 1.0f);
        }
        else {
            divCount = 1.0f / Timer1_COUNT_MAX;
            deltaPosition = 1.0f;
        }

        absSensedOe = (M_PI / 3.0f * Timer1_CLOCK_HZ) * divCount;

        if (isCCWHold) {
            position += deltaPosition;
            if (position > 6.0f) position -= 6.0f;
            sensedOe = absSensedOe;
        }
        else {
            position -= deltaPosition;
            if (position < 0.0f) position += 6.0f;
            sensedOe = -absSensedOe;
        }
        
        sensedPe = position * (M_PI / 3.0f);
        sensedOm = sensedOe / motorNp;
    }

    /* ad converter */
    iu =  Inverter_getIu() + iuOffset;
    iw =  Inverter_getIw() + iwOffset;
    vpn = Inverter_getVpn();
    vun = Inverter_getVun();
    vvn = Inverter_getVvn();
    vwn = Inverter_getVwn();
    iv =  Inverter_getIv() + ivOffset;
    vr1 = Inverter_getVr1();

    /* control mode switcher */
    {
        float absOm = fabs(om);
        controlMode =
            (absOm > controlThresholdOm + controlHysteresisOm) ? CONTROL_MODE_SPEED :
            (absOm < controlThresholdOm - controlHysteresisOm) ? CONTROL_MODE_OPEN :
            /* else */ controlMode; /* hold last mode */
    }

    /* speed controller */
    if (isRunning) {
        if (controlMode == CONTROL_MODE_SPEED) {
            /* feedback speed controller */
            float tmRefPI;
            float tmRefPRaw;
            om = sensedOm;
            oe = sensedOe;
            pe = sensedPe;
            tmRefPRaw = (omRef - om) * kpOm;
            tmRefP = wpOm * tmRefPRaw;
            tmRefI += (tmRefPRaw - tmRefOver) * kiOm;
            tmRefPFw = (wpOm - 1) * kpOm * om;
            tmRefPI = tmRefP + tmRefI + tmRefPFw;
            tmRef = fminf(fmaxf(tmRefPI, -tmLimit), tmLimit);
            tmRefOver = tmRefPI - tmRef;
            iqRef = tmRef / (motorKe * motorNp);
            idRef = 0.0f;
        }
        else {
            /* open loop speed controller */
            om += fminf(fmaxf(omRef - om, -openLoopOmStep), openLoopOmStep);
            oe = om * motorNp;
            pe += oe * (1.0f / Inverter_INTERRUPT_FREQUENCY_HZ);
            pe += (pe > 2.0f * M_PI) ? -2.0f * M_PI:
                (pe < 0.0f) ? 2.0f * M_PI:
                /* else */ 0.0f;
            tmRefP = 0.0f;
            tmRefI = 0.0f;
            tmRefPFw = 0.0f;
            tmRef = 0.0f;
            tmRefOver = 0.0f;
            iqRef = 0.0f;
            idRef = idRefOpen;
        }
    }
    else {
        om = sensedOm;
        oe = sensedOe;
        pe = sensedPe;
        tmRefP = 0.0f;
        tmRefI = 0.0f;
        tmRefPFw = 0.0f;
        tmRef = 0.0f;
        tmRefOver = 0.0f;
        iqRef = 0.0f;
        idRef = 0.0f;
    }

    /* uw-dq coordinate transformer */
    CoordXformer_transformUwToAb(iu, iw, &ia, &ib);
    CoordXformer_rotateXy(ia, ib, -pe, &id, &iq);

    /* current controller */
    if (isRunning) {
        float vdRefPI;
        float vqRefPI;
        float vdqLimit = vpn * vdqLimitFactor;

        vdRefP = (idRef - id) * kpId;
        vdRefI += (vdRefP - vdRefOver) * kiId;
        vdRefPI = vdRefP + vdRefI;
        vdRef = fminf(fmaxf(vdRefPI, -vdqLimit), vdqLimit);
        vdRefOver = vdRefPI - vdRef;

        vqRefP = (iqRef - iq) * kpIq;
        vqRefI += (vqRefP - vqRefOver) * kiIq;
        vqRefPI = vqRefP + vqRefI;
        vqRef = fminf(fmaxf(vqRefPI, -vdqLimit), vdqLimit);
        vqRefOver = vqRefPI - vqRef;

        /* dq-uvw coordinate transformer */
        CoordXformer_rotateXy(vdRef, vqRef, pe, &vaRef, &vbRef);
        CoordXformer_transformAbToUvw(vaRef, vbRef, &vuRef, &vvRef, &vwRef);

        /* pwm reference calcurator */
        {
            float x2DivVpn = 2.0f / vpn;
            muRef =  fminf(vuRef * x2DivVpn, mUpperLimit);
            mvRef =  fminf(vvRef * x2DivVpn, mUpperLimit);
            mwRef =  fminf(vwRef * x2DivVpn, mUpperLimit);
        }
    }
    else {
        vdRefP = 0.0f;
        vdRefI = 0.0f;
        vdRef = 0.0f;
        vdRefOver = 0.0f;

        vqRefP = 0.0f;
        vqRefI = 0.0f;
        vqRef = 0.0f;
        vqRefOver = 0.0f;

        vaRef = 0.0f;
        vbRef = 0.0f;

        vuRef = 0.0f;
        vvRef = 0.0f;
        vwRef = 0.0f;

        muRef =  0.0f;
        mvRef =  0.0f;
        mwRef =  0.0f;
    }

    Inverter_setPWMReference(muRef, mvRef, mwRef);

    blinkLED3();
    watchICS();
}

static void blinkLED3(void) {
    static int32_t counter = 0;
    if (++counter >= (Inverter_INTERRUPT_FREQUENCY_HZ / 2)) {
        LED3_turnOver();
        counter = 0;
    }
}

static void watchICS(void) {
    static int32_t counter = 0;
    if (++counter >= 3) {
        ics_watchpoint();
        counter = 0;
    }
}
