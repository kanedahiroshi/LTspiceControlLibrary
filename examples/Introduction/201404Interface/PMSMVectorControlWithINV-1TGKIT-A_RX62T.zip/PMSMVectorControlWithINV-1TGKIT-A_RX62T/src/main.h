#ifndef _Main
#define _Main

int main(void);
void Interrupt_HallSensorU(void);
void Interrupt_HallSensorV(void);
void Interrupt_HallSensorW(void);
void Interrupt_Inverter(void);

#endif /* _Main */
